wp.customize.controlConstructor['kirki-generic'] = wp.customize.kirkiDynamicControl.extend({});
